package com.example.meteor_arrows.entity;

import com.example.meteor_arrows.registry.ModItems;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;

public class PoopArrow extends AbstractArrow {
    public PoopArrow(EntityType<? extends PoopArrow> type, Level level) { super(type, level); }
    public PoopArrow(EntityType<? extends PoopArrow> type, LivingEntity shooter, Level level, ItemStack ammo, ItemStack weapon) { super(type, shooter, level, ammo, weapon); }
    @Override protected ItemStack getDefaultPickupItem() { return new ItemStack(ModItems.POOP_ARROW.get()); }
    @Override protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!level().isClientSide && result.getEntity() instanceof LivingEntity target) {
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0));
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0));
        }
    }
}
