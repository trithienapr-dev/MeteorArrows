package com.example.meteor_arrows.item;

import com.example.meteor_arrows.entity.MeteorArrow;
import com.example.meteor_arrows.registry.ModEntities;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class MeteorArrowItem extends ArrowItem {
    public MeteorArrowItem(Properties properties) { super(properties); }
    @Override public AbstractArrow createArrow(Level level, ItemStack stack, LivingEntity shooter, ItemStack weapon) {
        return new MeteorArrow(ModEntities.METEOR_ARROW.get(), shooter, level, stack, weapon);
    }
}
