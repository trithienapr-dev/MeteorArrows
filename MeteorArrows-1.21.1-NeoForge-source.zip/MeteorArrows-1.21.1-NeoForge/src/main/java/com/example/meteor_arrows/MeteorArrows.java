package com.example.meteor_arrows;

import com.example.meteor_arrows.registry.ModEntities;
import com.example.meteor_arrows.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MeteorArrows.MOD_ID)
public final class MeteorArrows {
    public static final String MOD_ID = "meteor_arrows";
    public MeteorArrows(FMLJavaModLoadingContext context) {
        IEventBus modBus = context.getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
    }
}
