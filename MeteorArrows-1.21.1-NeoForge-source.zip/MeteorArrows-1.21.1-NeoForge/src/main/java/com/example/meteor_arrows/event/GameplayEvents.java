package com.example.meteor_arrows.event;

import com.example.meteor_arrows.MeteorArrows;
import com.example.meteor_arrows.registry.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

@EventBusSubscriber(modid = MeteorArrows.MOD_ID, bus = EventBusSubscriber.Bus.GAME)
public final class GameplayEvents {
    private GameplayEvents() {}

    // Mob drops: small chance for a mob to leave a poop item when killed.
    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (event.getEntity().getRandom().nextFloat() < 0.20F) {
            ItemEntity drop = new ItemEntity(event.getEntity().level(),
                    event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(),
                    new ItemStack(ModItems.POOP_MATERIAL.get()));
            event.getDrops().add(drop);
        }
    }

    // Periodically spawn a falling meteor fragment above a random online player.
    // It is a simple falling item, not a custom animated meteor entity.
    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (level.getGameTime() % 24000L != 0L) return;
        if (level.players().isEmpty() || level.random.nextFloat() >= 0.35F) return;

        ServerPlayer player = level.players().get(level.random.nextInt(level.players().size()));
        int x = player.blockPosition().getX() + level.random.nextInt(81) - 40;
        int z = player.blockPosition().getZ() + level.random.nextInt(81) - 40;
        int y = Math.min(level.getMaxBuildHeight() - 5, Math.max(level.getMinBuildHeight() + 10, player.blockPosition().getY() + 35));
        ItemEntity fragment = new ItemEntity(level, x + 0.5, y, z + 0.5,
                new ItemStack(ModItems.METEOR_FRAGMENT.get()));
        fragment.setDeltaMovement(0.0, -0.35, 0.0);
        level.addFreshEntity(fragment);
    }
}
