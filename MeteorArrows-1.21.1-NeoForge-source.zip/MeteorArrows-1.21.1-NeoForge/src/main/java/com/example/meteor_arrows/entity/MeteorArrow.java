package com.example.meteor_arrows.entity;

import com.example.meteor_arrows.registry.ModItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class MeteorArrow extends AbstractArrow {
    public MeteorArrow(EntityType<? extends MeteorArrow> type, Level level) { super(type, level); }
    public MeteorArrow(EntityType<? extends MeteorArrow> type, LivingEntity shooter, Level level, ItemStack ammo, ItemStack weapon) {
        super(type, shooter, level, ammo, weapon);
        setBaseDamage(getBaseDamage() * 1.25);
        setPierceLevel((byte) 3);
    }
    @Override public void shoot(double x, double y, double z, float velocity, float inaccuracy) { super.shoot(x, y, z, velocity * 1.65F, inaccuracy); }
    @Override protected ItemStack getDefaultPickupItem() { return new ItemStack(ModItems.METEOR_ARROW.get()); }
}
