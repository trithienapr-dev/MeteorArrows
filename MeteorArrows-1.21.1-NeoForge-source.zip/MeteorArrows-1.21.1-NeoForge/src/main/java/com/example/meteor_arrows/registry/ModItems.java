package com.example.meteor_arrows.registry;

import com.example.meteor_arrows.MeteorArrows;
import com.example.meteor_arrows.item.MeteorArrowItem;
import com.example.meteor_arrows.item.PoopArrowItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MeteorArrows.MOD_ID);
    public static final Supplier<Item> POOP_MATERIAL = ITEMS.register("poop", () -> new Item(new Item.Properties()));
    public static final Supplier<Item> METEOR_FRAGMENT = ITEMS.register("meteor_fragment", () -> new Item(new Item.Properties()));
    public static final Supplier<Item> POOP_ARROW = ITEMS.register("poop_arrow", () -> new PoopArrowItem(new Item.Properties()));
    public static final Supplier<Item> METEOR_ARROW = ITEMS.register("meteor_arrow", () -> new MeteorArrowItem(new Item.Properties()));
    private ModItems() {}
}
