package com.example.meteor_arrows.registry;

import com.example.meteor_arrows.MeteorArrows;
import com.example.meteor_arrows.entity.MeteorArrow;
import com.example.meteor_arrows.entity.PoopArrow;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

public final class ModEntities {
    public static final DeferredRegister.Entities ENTITY_TYPES = DeferredRegister.createEntities(MeteorArrows.MOD_ID);
    public static final Supplier<EntityType<PoopArrow>> POOP_ARROW = ENTITY_TYPES.register("poop_arrow", () -> EntityType.Builder.<PoopArrow>of(PoopArrow::new, MobCategory.MISC).sized(0.5F, 0.5F).clientTrackingRange(4).updateInterval(20).build("poop_arrow"));
    public static final Supplier<EntityType<MeteorArrow>> METEOR_ARROW = ENTITY_TYPES.register("meteor_arrow", () -> EntityType.Builder.<MeteorArrow>of(MeteorArrow::new, MobCategory.MISC).sized(0.5F, 0.5F).clientTrackingRange(4).updateInterval(20).build("meteor_arrow"));
    private ModEntities() {}
}
