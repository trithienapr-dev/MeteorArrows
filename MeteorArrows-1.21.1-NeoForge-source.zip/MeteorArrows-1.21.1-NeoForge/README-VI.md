# Meteor Arrows — NeoForge 1.21.1

## Có trong mã nguồn mẫu
- `poop`: có 20% cơ hội rơi khi sinh vật bị hạ (cần kiểm thử trong game).
- `poop_arrow`: bắn trúng sinh vật sống gây Mù 5 giây và Buồn nôn 8 giây.
- `meteor_fragment`: sự kiện thử nghiệm định kỳ có thể thả mảnh từ trên trời gần người chơi; hiện là item rơi xuống, chưa có hoạt ảnh quả cầu lửa.
- `meteor_arrow`: tăng tốc độ bay và đặt pierce level 3.

## Lưu ý quan trọng
Đây là bộ mã nguồn khởi đầu, KHÔNG phải JAR đã biên dịch hoặc kiểm thử. Đã thêm xử lý rơi phân khi mob chết và sự kiện mảnh thiên thạch rơi dạng item. Đây vẫn là mã nguồn khởi đầu chưa được biên dịch/kiểm thử; API NeoForge 1.21.1 có thể cần chỉnh sửa khi đối chiếu với MDK chính thức.

## Build trên máy tính
1. Cài JDK 21.
2. Tải NeoForge MDK cho Minecraft 1.21.1 từ trang chính thức NeoForge.
3. Chép nội dung project này vào thư mục MDK, kiểm tra/cập nhật phiên bản Gradle plugin nếu MDK yêu cầu.
4. Chạy `gradlew.bat build` trên Windows hoặc `./gradlew build` trên Linux/macOS.
5. Nếu build thành công, JAR sẽ ở `build/libs/meteor_arrows-1.0.0.jar`.
6. Chép JAR vào thư mục `mods` của instance Minecraft 1.21.1 NeoForge trong Zalith. Sao lưu thế giới trước khi thử.

Minecraft Java 1.21.1 dùng Java 21. Nếu muốn bắn xuyên người chơi trên server, server cũng cần cài mod; cài client-only không thể thay đổi va chạm phía server. Chưa có texture riêng cho item.
